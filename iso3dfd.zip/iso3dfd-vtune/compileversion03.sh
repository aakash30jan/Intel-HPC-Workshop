make build version=dev03 model=cpu simd=avx2
