make build version=dev04 model=cpu simd=avx2
