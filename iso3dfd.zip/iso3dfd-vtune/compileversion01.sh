make build version=dev01 model=cpu simd=avx2
