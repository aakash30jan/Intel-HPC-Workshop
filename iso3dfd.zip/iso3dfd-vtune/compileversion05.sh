make build version=dev05 model=cpu simd=avx2
