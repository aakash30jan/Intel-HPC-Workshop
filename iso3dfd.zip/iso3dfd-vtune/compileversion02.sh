make build version=dev02 model=cpu simd=avx2
